import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    private EditText editTextID, editTextFecha, editTextAsunto, editTextActividad;
    private Button buttonGuardar;

    private static final String URL_INSERTAR = "http://tu_servidor/insertar.php";

    private OkHttpClient client;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextID = findViewById(R.id.editTextID);
        editTextFecha = findViewById(R.id.editTextFecha);
        editTextAsunto = findViewById(R.id.editTextAsunto);
        editTextActividad = findViewById(R.id.editTextActividad);
        buttonGuardar = findViewById(R.id.buttonGuardar);

        buttonGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                insertarDatos();
            }
        });

        client = new OkHttpClient();
    }

    private void insertarDatos() {
        final String id = editTextID.getText().toString().trim();
        final String fecha = editTextFecha.getText().toString().trim();
        final String asunto = editTextAsunto.getText().toString().trim();
        final String actividad = editTextActividad.getText().toString().trim();

        // Crear el cuerpo de la solicitud con los parámetros
        RequestBody requestBody = new FormBody.Builder()
                .add("id_agenda", id)
                .add("fecha", fecha)
                .add("asunto", asunto)
                .add("actividad", actividad)
                .build();

        // Crear la solicitud POST
        Request request = new Request.Builder()
                .url(URL_INSERTAR)
                .post(requestBody)
                .build();

        // Ejecutar la solicitud de forma asíncrona
        client.newCall(request).enqueue(new okhttp3.Callback() {
            @Override
            public void onResponse(okhttp3.Call call, Response response) {
                if (response.isSuccessful()) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(MainActivity.this, "Datos insertados correctamente", Toast.LENGTH_SHORT).show();
                        }
                    });
                } else {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(MainActivity.this, "Error al insertar datos", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }

            @Override
            public void onFailure(okhttp3.Call call, IOException e) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(MainActivity.this, "Error al realizar la solicitud", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }
}
